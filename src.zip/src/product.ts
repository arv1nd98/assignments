export class Vechile
{
    vechid:number;
    vechmodel:String;
    vechtype:String;
    vechbrand:String;
    vechnumber:number;
     vechcost:String;
}

