import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/dxc.model';

import { DxcUsersDaoService } from '../dxc-users-dao.service';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {

  constructor(private router:Router,private daosrv:DxcUsersDaoService) { }
 user_ID:number
 user_Name:string
 user_password:String
 
  

  ngOnInit(): void {
  }
  user1:User={"user_ID":0,"user_Name":"","user_password":"" ,"user_FullName":"","user_SecurityQuestion":"","user_SecurityAnswer":""};
  
  login()
{


  this.daosrv.loginuser(this.user_Name).subscribe(
    data=>{this.user1=data;
    if(this.user1.user_Name==this.user_Name && this.user1.user_password==this.user_password)
    {
     
      console.log(this.user_Name);
      console.log(this.user_password +"logged in");
    this.router.navigate(['product'])
        
     
    }
   
    
    
    },
    error=>console.log(error)
  );


  
   
    
    

  }
  
 

// }
 reguser()
 {
  
this.router.navigate(['register']);
 }
forget()
{
  this.router.navigate(['forget']);
}
}
