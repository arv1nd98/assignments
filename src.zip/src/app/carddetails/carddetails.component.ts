import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-carddetails',
  templateUrl: './carddetails.component.html',
  styleUrls: ['./carddetails.component.css']
})
export class CarddetailsComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  otp()
  {
    this.router.navigate(['checkout'])
  }

}
