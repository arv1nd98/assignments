import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { stringify } from 'querystring';
import { Product } from '../entities/product.entity';
import { ProserviceService } from '../proservice.service';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-pro',
  templateUrl: './pro.component.html',
  styleUrls: ['./pro.component.css']
})
export class ProComponent implements OnInit {

  
  private products: Product[];
  private id:any

	constructor(
		private productService: ProserviceService,private router:Router,	private activatedRoute: ActivatedRoute,
	) { }

	ngOnInit() {
      this.products = this.productService.findAll();
		
	}
   getpro()
   {
	this.products = this.productService.findAll();
	
	
   }
  
addcart(val)
{ this.id=this.productService.find(this.id);
   console.log(val)
   localStorage.setItem("id",val);

   this.router.navigate(['addcart']);
}
   
}
