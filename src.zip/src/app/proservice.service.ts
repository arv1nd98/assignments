import { Injectable } from '@angular/core';
import { Product } from './entities/product.entity';

@Injectable({
  providedIn: 'root'
})
export class ProserviceService {

  private products: Product[];

    constructor() {
        this.products = [
            { id : '1', vechmodel : 'Creta', vechtype: 'car',vechbrand:'Hyundai', vechnumber : 20, vechcost:'Rs.20.57 Lakh',vechimage:'imgg1.jpg'},
            { id : '2', vechmodel : 'Santro', vechtype: 'car',vechbrand:'Hyundai', vechnumber : 20, vechcost:'Rs.5.81 Lakh',vechimage:'img2.jpg'},
            { id : '3', vechmodel : 'Xcent', vechtype: 'car',vechbrand:'Hyundai', vechnumber : 20, vechcost:'Rs. 17.6 Lakh',vechimage:'img3.jpg'},       
            { id : '4', vechmodel : 'Vellfire', vechtype: 'car',vechbrand:'Toyota', vechnumber : 20, vechcost:'Rs.83.5 Lakh',vechimage:'img4.jpg'},  
            { id : '5', vechmodel : 'Camry', vechtype: 'car',vechbrand:'Toyota', vechnumber : 20, vechcost:'Rs. 39.02 Lakh',vechimage:'img5.jpg'},
            { id : '6', vechmodel : 'Prius', vechtype: 'car',vechbrand:'Toyota', vechnumber : 20, vechcost:'Rs. 45.09 Lakh',vechimage:'img6.jpg'},
            { id : '7', vechmodel : 'X3', vechtype: 'car',vechbrand:'BMW', vechnumber : 20, vechcost:'Rs. 60.5-60.9 Lakh',vechimage:'img7.jpg'},
            { id : '8', vechmodel : '5 Series', vechtype: 'car',vechbrand:'BMW', vechnumber : 20, vechcost:'Rs. 55.4-68.4  Lakh',vechimage:'img8.jpg'},
            { id : '9', vechmodel : 'X4', vechtype: 'car',vechbrand:'BMW', vechnumber : 20, vechcost:'Rs. 62.4-67.9 Lakh',vechimage:'img9.jpg'},
            { id : '10', vechmodel : 'Sp 125', vechtype: 'Bike',vechbrand:'Honda', vechnumber : 20, vechcost:'Rs. 74,407',vechimage:'b1.jpg'},
            { id : '11', vechmodel : 'Livo BS6', vechtype: 'Bike',vechbrand:'Honda', vechnumber : 20, vechcost:'Rs. 70,056',vechimage:'b2.jpg'},
            { id : '12', vechmodel : 'XBlade', vechtype: 'Bike',vechbrand:'Honda', vechnumber : 20, vechcost:'Rs. 1.06 Lakh',vechimage:'b3.jpg'},       
            { id : '13', vechmodel : 'Himalayan', vechtype: 'Bike',vechbrand:'Royal Enfield', vechnumber : 20, vechcost:'Rs. 1.89Lakh',vechimage:'b4.jpg'},  
            { id : '14', vechmodel : 'Interceptor 650', vechtype: 'Bike',vechbrand:'Royal Enfield', vechnumber : 20, vechcost:'Rs. 2.64 Lakh',vechimage:'b5.jpg'},
            { id : '15', vechmodel : 'Continental GT 650', vechtype: 'Bike',vechbrand:'Royal Enfield', vechnumber : 20, vechcost:'Rs. 2.8 Lakh',vechimage:'b6.png'},
            { id : '16', vechmodel : '200 Duke', vechtype: 'Bike',vechbrand:'KTM', vechnumber : 20, vechcost:'Rs. 1.76 Lakh',vechimage:'b7.jpg'},
            { id : '17', vechmodel : '125 Duke', vechtype: 'Bike',vechbrand:'KTM', vechnumber : 20, vechcost:'Rs. 1.42 Lakh',vechimage:'b8.jpg'},
            { id : '18', vechmodel : 'RC 200', vechtype: 'Bike',vechbrand:'KTM', vechnumber : 20, vechcost:'Rs. 2 Lakh',vechimage:'b9.jpg'}
            
        ];
    }

    findAll(): Product[] {
        return this.products;
    }

    find(id: string): Product {
        return this.products[this.getSelectedIndex(id)];
    }

    private getSelectedIndex(id: string) {
        for (var i = 0; i < this.products.length; i++) {
            if (this.products[i].id == id) {
                return i;
            }
        }
        return -1;
    }
}
