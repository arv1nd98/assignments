import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Address } from 'src/address.model';

@Injectable({
  providedIn: 'root'
})
export class AddressService {

  constructor(private http:HttpClient) { }



  saveaddress(address:Address)
 {

 return this.http.post<any>(`http://localhost:1111/saveaddr`,address); 
 }
 
 getaddress(phno:string)
 {

 return this.http.get<any>(`http://localhost:1111/address/${phno}`); 
 }
 
 




}
