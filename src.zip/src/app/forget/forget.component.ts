import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/dxc.model';
import { DxcUsersDaoService } from '../dxc-users-dao.service';

@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.css']
})
export class ForgetComponent implements OnInit {

  constructor(private router:Router,private daosrv:DxcUsersDaoService) { }
  user_Name:string
  user_SecurityQuestion:string
  user_SecurityAnswer:string
  

  ngOnInit(): void {
  }
  user2:User={"user_ID":0,"user_Name":"","user_password":"" ,"user_FullName":"","user_SecurityQuestion":"","user_SecurityAnswer":""};
  forgetpass()
{


  this.daosrv.forget(this.user_Name).subscribe(
    data=>{this.user2=data;
    if(this.user2.user_Name==this.user_Name &&  this.user2.user_SecurityAnswer==this.user_SecurityAnswer)
    {
     
      console.log(this.user_Name);
     
    this.router.navigate(['changepass'])
        
     
    }
   
    
    
    },
    error=>console.log(error)
  );


   
    
    

  }
  







}
