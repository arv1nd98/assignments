import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetaddrComponent } from './getaddr.component';

describe('GetaddrComponent', () => {
  let component: GetaddrComponent;
  let fixture: ComponentFixture<GetaddrComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetaddrComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetaddrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
